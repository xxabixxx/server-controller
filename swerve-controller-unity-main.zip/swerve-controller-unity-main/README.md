# swerve-controller-unity
another generic swerve controller I wrote for Unity

~ clone, add `Swerve.cs` to player, adjust parameters in inspector, player go brr<br>

<img src="demo.gif"><br>
*working on this game that uses this script* 
